/**
 * AI Campaign Generator - Frontend Integration
 * Integração com Nexora IA e Manus IA para geração automática de campanhas
 */

class AICampaignGeneratorUI {
    constructor() {
        this.isGenerating = false;
        this.generatedCampaign = null;
        this.generatedAds = [];
    }

    /**
     * Inicializa o gerador de IA
     */
    init() {
        this.createAIButton();
        this.createAIModal();
        this.setupEventListeners();
    }

    /**
     * Cria botão de geração com IA
     */
    createAIButton() {
        // Adicionar botão no step 2 (após seleção de plataforma e objetivo)
        const step2Footer = document.querySelector('#content-step2 .card-footer');
        if (step2Footer) {
            const aiButton = document.createElement('button');
            aiButton.type = 'button';
            aiButton.className = 'btn btn-success btn-lg';
            aiButton.id = 'generateWithAIBtn';
            aiButton.innerHTML = '<i class="fas fa-magic"></i> Gerar Anúncios com IA';
            aiButton.onclick = () => this.showAIModal();
            
            // Inserir antes do botão "Próximo"
            const nextBtn = step2Footer.querySelector('.btn-primary');
            if (nextBtn) {
                nextBtn.parentNode.insertBefore(aiButton, nextBtn);
            }
        }
    }

    /**
     * Cria modal de geração com IA
     */
    createAIModal() {
        const modalHTML = `
        <div class="modal fade" id="aiGeneratorModal" tabindex="-1" aria-labelledby="aiGeneratorModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header bg-gradient-primary text-white">
                        <h5 class="modal-title" id="aiGeneratorModalLabel">
                            <i class="fas fa-robot"></i> Gerador de Campanhas com IA
                        </h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Formulário de configuração da IA -->
                        <div id="aiConfigForm">
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle"></i>
                                <strong>Nexora IA + Manus IA</strong> vão gerar anúncios personalizados automaticamente baseados nas suas configurações.
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Produto/Serviço <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="aiProduto" placeholder="Ex: Curso de Marketing Digital" required>
                                    <small class="text-muted">Nome do produto ou serviço que será anunciado</small>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Público-Alvo <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="aiPublico" placeholder="Ex: Empreendedores de 25-45 anos" required>
                                    <small class="text-muted">Descreva o público que deseja atingir</small>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Tom de Voz <span class="text-danger">*</span></label>
                                    <select class="form-select" id="aiVoz" required>
                                        <option value="">Selecione...</option>
                                        <option value="profissional">Profissional</option>
                                        <option value="casual">Casual/Descontraído</option>
                                        <option value="urgente">Urgente/Promocional</option>
                                        <option value="inspirador">Inspirador/Motivacional</option>
                                    </select>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Quantidade de Anúncios</label>
                                    <select class="form-select" id="aiQuantidade">
                                        <option value="3" selected>3 anúncios</option>
                                        <option value="5">5 anúncios</option>
                                        <option value="10">10 anúncios</option>
                                    </select>
                                </div>
                            </div>

                            <div class="d-grid gap-2 mt-4">
                                <button type="button" class="btn btn-success btn-lg" id="startAIGenerationBtn" onclick="aiGenerator.generateCampaign()">
                                    <i class="fas fa-magic"></i> Gerar Anúncios com IA
                                </button>
                            </div>
                        </div>

                        <!-- Loading state -->
                        <div id="aiLoadingState" style="display: none;" class="text-center py-5">
                            <div class="spinner-border text-primary mb-3" role="status" style="width: 4rem; height: 4rem;">
                                <span class="visually-hidden">Gerando...</span>
                            </div>
                            <h4>Nexora IA + Manus IA trabalhando...</h4>
                            <p class="text-muted">Gerando anúncios personalizados para sua campanha</p>
                            <div class="progress" style="height: 25px;">
                                <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" id="aiProgressBar" style="width: 0%">0%</div>
                            </div>
                        </div>

                        <!-- Resultados -->
                        <div id="aiResults" style="display: none;">
                            <div class="alert alert-success">
                                <i class="fas fa-check-circle"></i>
                                <strong>Sucesso!</strong> Anúncios gerados com IA. Revise e edite conforme necessário.
                            </div>

                            <!-- Informações da campanha -->
                            <div class="card mb-3">
                                <div class="card-header bg-light">
                                    <h6 class="mb-0"><i class="fas fa-info-circle"></i> Informações da Campanha</h6>
                                </div>
                                <div class="card-body" id="campaignInfo"></div>
                            </div>

                            <!-- Métricas estimadas -->
                            <div class="card mb-3">
                                <div class="card-header bg-light">
                                    <h6 class="mb-0"><i class="fas fa-chart-line"></i> Métricas Estimadas</h6>
                                </div>
                                <div class="card-body">
                                    <div class="row" id="estimatedMetrics"></div>
                                </div>
                            </div>

                            <!-- Anúncios gerados -->
                            <div class="card mb-3">
                                <div class="card-header bg-light">
                                    <h6 class="mb-0"><i class="fas fa-ad"></i> Anúncios Gerados</h6>
                                </div>
                                <div class="card-body" id="generatedAds"></div>
                            </div>

                            <!-- Recomendações da IA -->
                            <div class="card mb-3">
                                <div class="card-header bg-light">
                                    <h6 class="mb-0"><i class="fas fa-lightbulb"></i> Recomendações da IA</h6>
                                </div>
                                <div class="card-body" id="aiRecommendations"></div>
                            </div>

                            <div class="d-grid gap-2">
                                <button type="button" class="btn btn-primary btn-lg" onclick="aiGenerator.applyGeneratedCampaign()">
                                    <i class="fas fa-check"></i> Aplicar Anúncios à Campanha
                                </button>
                                <button type="button" class="btn btn-outline-secondary" onclick="aiGenerator.resetGenerator()">
                                    <i class="fas fa-redo"></i> Gerar Novamente
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        `;

        document.body.insertAdjacentHTML('beforeend', modalHTML);
    }

    /**
     * Configura event listeners
     */
    setupEventListeners() {
        // Listener para mudanças de plataforma/objetivo
        const platformInputs = document.querySelectorAll('input[name="platform"]');
        platformInputs.forEach(input => {
            input.addEventListener('change', () => this.updateAIButtonState());
        });

        const objectiveSelect = document.getElementById('campaignObjective');
        if (objectiveSelect) {
            objectiveSelect.addEventListener('change', () => this.updateAIButtonState());
        }
    }

    /**
     * Atualiza estado do botão de IA
     */
    updateAIButtonState() {
        const aiBtn = document.getElementById('generateWithAIBtn');
        if (!aiBtn) return;

        const platform = document.querySelector('input[name="platform"]:checked');
        const objective = document.getElementById('campaignObjective').value;

        if (platform && objective) {
            aiBtn.disabled = false;
            aiBtn.classList.remove('btn-secondary');
            aiBtn.classList.add('btn-success');
        } else {
            aiBtn.disabled = true;
            aiBtn.classList.remove('btn-success');
            aiBtn.classList.add('btn-secondary');
        }
    }

    /**
     * Mostra modal de geração com IA
     */
    showAIModal() {
        const platform = document.querySelector('input[name="platform"]:checked');
        const objective = document.getElementById('campaignObjective').value;

        if (!platform || !objective) {
            alert('Por favor, selecione uma plataforma e objetivo primeiro.');
            return;
        }

        const modal = new bootstrap.Modal(document.getElementById('aiGeneratorModal'));
        modal.show();
    }

    /**
     * Gera campanha com IA
     */
    async generateCampaign() {
        // Validar campos
        const produto = document.getElementById('aiProduto').value.trim();
        const publico = document.getElementById('aiPublico').value.trim();
        const voz = document.getElementById('aiVoz').value;

        if (!produto || !publico || !voz) {
            alert('Por favor, preencha todos os campos obrigatórios.');
            return;
        }

        // Obter dados do formulário principal
        const platform = document.querySelector('input[name="platform"]:checked').value;
        const objetivo = document.getElementById('campaignObjective').value;
        const quantidade = parseInt(document.getElementById('aiQuantidade').value);

        // Mostrar loading
        this.showLoading();

        try {
            // Simular progresso
            this.updateProgress(20);

            // Chamar API de geração
            const response = await fetch('/api/ai/generate-campaign', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    plataforma: platform,
                    objetivo: objetivo,
                    publico: publico,
                    produto: produto,
                    voz: voz,
                    quantidade_anuncios: quantidade
                })
            });

            this.updateProgress(60);

            if (!response.ok) {
                throw new Error('Erro ao gerar campanha');
            }

            const result = await response.json();

            this.updateProgress(90);

            if (result.success) {
                this.generatedCampaign = result.campanha;
                this.generatedAds = result.anuncios;
                
                this.updateProgress(100);
                
                // Aguardar um pouco para mostrar 100%
                await new Promise(resolve => setTimeout(resolve, 500));
                
                // Mostrar resultados
                this.showResults(result);
            } else {
                throw new Error(result.error || 'Erro desconhecido');
            }

        } catch (error) {
            console.error('Erro ao gerar campanha:', error);
            alert('Erro ao gerar campanha com IA: ' + error.message);
            this.resetGenerator();
        }
    }

    /**
     * Mostra estado de loading
     */
    showLoading() {
        this.isGenerating = true;
        document.getElementById('aiConfigForm').style.display = 'none';
        document.getElementById('aiLoadingState').style.display = 'block';
        document.getElementById('aiResults').style.display = 'none';
        this.updateProgress(0);
    }

    /**
     * Atualiza barra de progresso
     */
    updateProgress(percent) {
        const progressBar = document.getElementById('aiProgressBar');
        progressBar.style.width = percent + '%';
        progressBar.textContent = percent + '%';
    }

    /**
     * Mostra resultados da geração
     */
    showResults(data) {
        document.getElementById('aiLoadingState').style.display = 'none';
        document.getElementById('aiResults').style.display = 'block';

        // Informações da campanha
        const campaignInfo = `
            <div class="row">
                <div class="col-md-6">
                    <p><strong>Nome:</strong> ${data.campanha.nome}</p>
                    <p><strong>Plataforma:</strong> ${data.campanha.plataforma}</p>
                    <p><strong>Objetivo:</strong> ${data.campanha.objetivo}</p>
                </div>
                <div class="col-md-6">
                    <p><strong>Público:</strong> ${data.campanha.publico_alvo}</p>
                    <p><strong>Tom de Voz:</strong> ${data.campanha.tom_de_voz}</p>
                    <p><strong>IA Utilizada:</strong> ${data.campanha.ia_utilizada.join(', ')}</p>
                </div>
            </div>
        `;
        document.getElementById('campaignInfo').innerHTML = campaignInfo;

        // Métricas estimadas
        const metrics = data.metricas_estimadas;
        const metricsHTML = `
            <div class="col-md-3 text-center">
                <h4 class="text-primary">${metrics.alcance_estimado}</h4>
                <small class="text-muted">Alcance Estimado</small>
            </div>
            <div class="col-md-3 text-center">
                <h4 class="text-success">${metrics.cliques_estimados}</h4>
                <small class="text-muted">Cliques Estimados</small>
            </div>
            <div class="col-md-3 text-center">
                <h4 class="text-info">${metrics.ctr_medio}</h4>
                <small class="text-muted">CTR Médio</small>
            </div>
            <div class="col-md-3 text-center">
                <h4 class="text-warning">${metrics.roi_estimado}</h4>
                <small class="text-muted">ROI Estimado</small>
            </div>
        `;
        document.getElementById('estimatedMetrics').innerHTML = metricsHTML;

        // Anúncios gerados
        let adsHTML = '';
        data.anuncios.forEach((ad, index) => {
            adsHTML += `
                <div class="card mb-3">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                        <h6 class="mb-0">Anúncio ${ad.variacao} - Score IA: ${ad.score_ia}/10</h6>
                        <span class="badge bg-success">${ad.estimativa_ctr} CTR estimado</span>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Título</label>
                                    <input type="text" class="form-control" value="${ad.titulo}" id="ad${index}_titulo">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Descrição</label>
                                    <input type="text" class="form-control" value="${ad.descricao}" id="ad${index}_descricao">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Texto Principal</label>
                                    <textarea class="form-control" rows="5" id="ad${index}_texto">${ad.texto_principal}</textarea>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Call-to-Action</label>
                                    <input type="text" class="form-control" value="${ad.cta}" id="ad${index}_cta">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Prompt da Imagem</label>
                                    <textarea class="form-control" rows="4" id="ad${index}_prompt">${ad.imagem_prompt}</textarea>
                                    <button class="btn btn-sm btn-primary mt-2 w-100">
                                        <i class="fas fa-image"></i> Gerar Imagem com IA
                                    </button>
                                </div>
                                <div class="mb-3">
                                    <p class="mb-1"><strong>Formato:</strong> ${ad.formato}</p>
                                    <p class="mb-1"><strong>Tags:</strong> ${ad.tags.join(', ')}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        });
        document.getElementById('generatedAds').innerHTML = adsHTML;

        // Recomendações
        let recsHTML = '<div class="row">';
        data.recomendacoes.forEach(rec => {
            const badgeClass = rec.prioridade === 'alta' ? 'bg-danger' : 'bg-warning';
            recsHTML += `
                <div class="col-md-6 mb-3">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h6 class="card-title">${rec.titulo}</h6>
                                <span class="badge ${badgeClass}">${rec.prioridade}</span>
                            </div>
                            <p class="card-text small text-muted">${rec.descricao}</p>
                            <small class="text-muted"><i class="fas fa-tag"></i> ${rec.tipo}</small>
                        </div>
                    </div>
                </div>
            `;
        });
        recsHTML += '</div>';
        document.getElementById('aiRecommendations').innerHTML = recsHTML;

        this.isGenerating = false;
    }

    /**
     * Aplica campanha gerada ao formulário
     */
    applyGeneratedCampaign() {
        if (!this.generatedCampaign || !this.generatedAds.length) {
            alert('Nenhuma campanha gerada para aplicar.');
            return;
        }

        // Preencher nome da campanha
        document.getElementById('campaignName').value = this.generatedCampaign.nome;

        // Fechar modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('aiGeneratorModal'));
        modal.hide();

        // Mostrar mensagem de sucesso
        showToast('Anúncios aplicados com sucesso! Continue configurando sua campanha.', 'success');

        // Avançar para próximo passo
        nextStep(3);
    }

    /**
     * Reseta o gerador
     */
    resetGenerator() {
        this.isGenerating = false;
        this.generatedCampaign = null;
        this.generatedAds = [];
        
        document.getElementById('aiConfigForm').style.display = 'block';
        document.getElementById('aiLoadingState').style.display = 'none';
        document.getElementById('aiResults').style.display = 'none';
        
        // Limpar campos
        document.getElementById('aiProduto').value = '';
        document.getElementById('aiPublico').value = '';
        document.getElementById('aiVoz').value = '';
        document.getElementById('aiQuantidade').value = '3';
    }
}

// Inicializar quando o DOM estiver pronto
let aiGenerator;
document.addEventListener('DOMContentLoaded', function() {
    aiGenerator = new AICampaignGeneratorUI();
    aiGenerator.init();
});
